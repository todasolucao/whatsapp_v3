<script type='text/javascript' src="cadastros/menu/acoes.js"></script>
<script>
    $(document).ready(function() {	
        $.ajax("cadastros/menu/listar.php").done(function(data) {
          $('#ListarMenu').html(data);
        });

        // Fechar a Janela //
		$('.fechar').on("click", function(){ fecharModal(); });
    });
</script>

<div class="box-modal" id="FormMenu" style="display: none;">
    <form method="post" id="gravaMenu" name="gravaMenu" action="cadastros/menu/salvar.php">
        <h2 class="title" id="titleCadastroMenu">Adicionar Novo Menu</h2>
        <div class="">
            <input type="hidden" value="0" name="acaomenu" id="acaomenu" />

            <div class="uk-width-1-1@m">
                <div class="uk-form-label">Menu Superior</div>
                <input type="hidden" name="id" id="id" value="0">
                <select name="id_menu" id="id_menu" class="uk-select">                    
                    <?php
                       require_once("combomenu.php");
                    ?>
                    
                </select>
            </div>

            <div class="uk-width-1-1@m">
                <div class="uk-form-label"> Descrição do Item do Menu </div>
                <input type="text" id="txtmenu" name="txtmenu" class="uk-input" placeholder="Descrição do Item do Menu" />
                <div id="valida_menu" style="display: none" class="msgValida">
                    Por favor, informe a Descrição do Item do Menu.
                </div>
            </div>
        </div>
    </form>

    <p class="uk-text-right" style="margin-top:1rem">
        <button id="btnFecharCadastroMenu" class="uk-button uk-button-default uk-modal-close" type="button">Cancelar</button>
        <input id="btnGravarMenu" class="uk-button uk-button-primary " type="submit" value="Salvar">
    </p>
</div>

<div class="box-modal" id="ListaMenus">
    <h2 class="title">Menus Cadastrados <a id="btnNovoMenu" href="#" class="uk-align-right" uk-icon="plus-circle" title="Novo Menu"></a></h2>

    <div class="panel-body" id="ListarMenu">				
        <!-- Menus Cadastrados -->
    </div>

    <p class="uk-text-right" style="margin-top:1rem">
        <button class="uk-button uk-button-default uk-modal-close fechar" type="button">Cancelar</button>
    </p>
</div>