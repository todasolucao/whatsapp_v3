// JavaScript Document
$( document ).ready(function() {
	
	// Adicionar Novo Registro //
	$('#btnNovoMenu').click(function(e){
		e.preventDefault();
		$("#gravaMenu")[0].reset();
		$("#FormMenu").css("display","block");
		$("#ListaMenus").css("display","none");
		$("#acaomenu").val("0");
	});
	// Adicionar Novo Registro //

    // Salvando um Registro //
	$('#btnGravarMenu').click(function(e){
		e.preventDefault();


		var mensagem  = "<strong>Menu Cadastrado com sucesso!</strong>";
		var mensagem2 = 'Falha ao Efetuar Cadastro!';
		var mensagem3 = 'Menu Já Cadastrado!';
		var mensagem4 = 'Menu Atualizado com Sucesso!';

		

		$("input:text").css({"border-color" : "#999"});
		$(".msgValida").css({"display" : "none"});
	    
		if ($.trim($("#txtmenu").val()) == ''){
			$("#valida_menu").css({"display" : "inline", "color" : "red"});
			$("#txtmenu").css({"border-color" : "red"});
			$("#txtmenu").focus();
			return false;
		}

		$('#id_menu').prop('disabled', false);

	    $('#gravaMenu').ajaxForm({
			resetForm: false, 			  
			beforeSend:function() { 
				$("#btnGravarMenu").attr('value', 'Salvando ...');
				$('#btnGravarMenu').attr('disabled', true);
				$('#btnFecharCadastro').attr('disabled', true);
				$('#FormMenu').find('input').prop('disabled', true);
			},
			success: function( retorno ){
			//	alert(retorno);
				if (retorno == 1) { mostraDialogo(mensagem, "success", 2500); }
				else if (retorno == 2){ mostraDialogo(mensagem4, "success", 2500); }
				else if (retorno == 3){ mostraDialogo(mensagem3, "danger", 2500); }
				else if (retorno == 4){ mostraDialogo(mensagem4, "success", 2500); }
				else if (retorno == 5){ mostraDialogo(mensagem5, "danger", 2500); }
				else{ 
				//	alert(retorno);
					
				//	mostraDialogo(mensagem2+retorno, "danger", 2500); 
				}
                
				$.ajax("cadastros/menu/listar.php").done(function(data) {
					$('#ListarMenu').html(data);
				});
				//Atualizo a lista
				$.ajax("cadastros/menu/combomenu.php").done(function(data) {
					$('#id_menu').html(data);
				});
			},		 
			complete:function(retorno) {
			//	alert(retorno);
				$("#btnGravarMenu").attr('value', 'Salvar');
				$('#btnGravarMenu').attr('disabled', false);
				$('#FormMenu').find('input, button').prop('disabled', false);
				$("#ListaMenus").css("display","block");
				$("#FormMenu").css("display","none");
				
			},
			error: function (retorno) {
			//	alert(retorno);
				 mostraDialogo(mensagem5, "danger", 2500);
			 
		}
		}).submit();
	});
	// FIM Salvando um Registro //  


	$.ajax("cadastros/menu/combomenu.php").done(function(data) {
		$('#id_menu').html(data);
	});


});